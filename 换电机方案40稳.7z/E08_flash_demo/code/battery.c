/////*
//// * battery.c
//// *
//// *  Created on: Dec 25, 2023
//// *      Author: ������
//// */
////
//#include "zf_common_headfile.h"
//#include "battery.h"
///*************���ADC�ɼ�**********/
//void battery_voltage_get(void)
//{
//    uint16 adc_value;
//    uint16 pin_voltage;
//    static uint16 low_power_num;
//   // adc_init(ADC2_IN10_C0,ADC_8BIT);
//    adc_value=adc_convert(ADC2_IN10_C0);
//    pin_voltage=(uint32)adc_value*5000/256;//��ADCֻת��Ϊʵ�ʵĵ�ѹ
//    battery_voltage=(uint32)pin_voltage*57/10;//����Ӳ����ѹ�����ֵ�������ص�ѹ
//   if((BLDC_MIN_BATTERY*1000>battery_voltage)&&(0==battery_low_voltage))
//{
//       low_power_num++;
//       if(100<low_power_num)
//       {
//           battery_low_voltage=1;
//       }
//
//
//}
//   else
//       {
//       low_power_num=0;
//
//       }
//}


