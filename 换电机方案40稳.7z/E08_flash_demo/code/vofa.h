/*
 * vofa.h
 *
 *  Created on: 2024��3��20��
 *      Author: ������
 */
#include "zf_common_headfile.h"
#ifndef VOFA_H_
#define VOFA_H_
typedef union
{
    float fdata;
    unsigned long ldata;
}FloatLongType;
void Float_to_Byte(float f,unsigned char byte[]);

void vofa_send_data (float f);
void vofa_tail(void);
#endif /* VOFA_H_ */
