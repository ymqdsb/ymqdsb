
#ifndef VOFAPP_H_
#define VOFAPP_H_

#include "zf_common_headfile.h"

#define VOFA_UART_INDEX            (UART_7)                 // ָ�� VOFA ��ʹ�õĵĴ���
#define VOFA_UART_BAUDRATE         (460800)

#define VOFA_UART_TX_PIN           (UART7_MAP3_RX_E13)      // ָ�� VOFA ��ʹ�õĵĴ�������    ʹ��WSHLINKĬ�ϴ�������
#define VOFA_UART_RX_PIN           (UART7_MAP3_TX_E12)      // ָ�� VOFA ��ʹ�õĵĴ�������




//#define VOFA_UART_PRIORITY           USART3_IRQn



typedef union
{
    float floatData;
    unsigned char byteData[4];
}FLOAT_BYTE;

typedef struct
{
    u8     biaozhi;
    float  p;
    float  i;
    float  d;

    float  A;
    float  B;
    float  C;

    float  TIM;


}MY_VOFA;


extern MY_VOFA my_dat;
void VOFA_INIT( void );
void VOFA_write_byte( const uint8 dat );
void VOFA_write_float( float dat );
void VOFA_write_int( int dat );
void VOFA_write_string(const char *str);
void VOFA_send_image (const uint8 *image_addr, uint32 image_size);
void Just_end( void );
void VOFA_rx_interrupt_handler (void);
void USART_PID_Adjust (void);
float Get_Data(void);
void HAL_UART_RxCpltCallback (void);

#endif /* VOFAPP_H_ */
