/*
 * TFT.c
 *
 *  Created on: 2024��3��24��
 *      Author: ������
 */

#ifndef TFT_C_
#define TFT_C_
#include "zf_common_headfile.h"
#include "image3.h"
#include "camer.h"
//#include "image.h"
//#include"LQ_ImageProcess.h"
//int image_thereshold;
void imageshow(void)
{

   // image_thereshold=my_adapt_threshold(mt9v03x_image[0],MT9V03X_W,MT9V03X_H);
    image_thereshold=otsuThreshold(mt9v03x_image[0],MT9V03X_W,MT9V03X_H,10);
    Get_image(1);
    tft180_show_gray_image (0, 0,mt9v03x_image[0], MT9V03X_W, MT9V03X_H, MT9V03X_W/2, MT9V03X_H/2,image_thereshold);

    Binarization(original_image[0],MT9V03X_W,MT9V03X_H,image_thereshold);

    findline(original_image[0],MT9V03X_W,MT9V03X_H);
 //   centerlinefix();
   // turnerr=centerline_err();

    for (int i = 0; i < MT9V03X_H; i++)
    {
       tft180_draw_point(leftborder[i]/2 ,i /2,RGB565_RED);
       tft180_draw_point(centerline[i]/2,i/2,RGB565_GREEN);
       tft180_draw_point(rightborder[i]/2,i/2,RGB565_BLUE);

    }
}

/*****************��������ֵ��ȡ******************/
int start_flag=0;
int star=0;
 void GET_RUN_KEY(void)
{

    start_flag=gpio_get_level(KEY4);

    //key_clear_state(KEY4);


}









#endif /* TFT_C_ */
