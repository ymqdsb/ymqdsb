/*
 * speeedchange.h
 *
 *  Created on: 2024��6��6��
 *      Author: ������
 */

#ifndef SPEEDCHANGE_H_
#define SPEEDCHANGE_H_

#include "zf_common_headfile.h"

extern int road_mode;

void speedjudge();



#endif /* SPEEDCHANGE_H_ */
