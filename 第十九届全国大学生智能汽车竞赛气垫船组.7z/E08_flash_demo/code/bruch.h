/*
 * bruch.h
 *
 *  Created on: 2024��3��13��
 *      Author: ������
 */

#ifndef BRUCH_H_
#define BRUCH_H_

#include "zf_common_headfile.h"
void limit_bruch_duty2(float duty);

float  limit_bruch_duty(float duty);
void left_back_bruch_set_duty(float allduty);
void right_back_bruch_set_duty(float rightallduty);
void right_side_bruch_set_duty(float rightallduty);
void left_side_bruch_set_duty(float leftallduty);
void bruch_init(void);
extern float stop_flag;
extern float put1;
extern float put2;
extern float put3;
extern float put4;

//extern float duty;
//extern float leftallduty;// ��������pwm
//extern float rightallduty;// ��������pwm
#endif /* BRUCH_H_ */
