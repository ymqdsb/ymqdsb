/*
 * bruchless.h
 *
 *  Created on: Mar 6, 2024
 *      Author: ������
 */

#ifndef BRUCHLESS_H_
#define BRUCHLESS_H_

#include "zf_common_headfile.h"
void bruchlessgo(float bruchlesspwm);
void bruchless_init(void);
//extern float bruchlesspwm;
#endif /* BRUCHLESS_H_ */
