/*
 * battery.h
 *
 *  Created on: Dec 25, 2023
 *      Author: ������
 */

//#ifndef BATTERY_H_
//#define BATTERY_H_
//extern uint8 battery_low_voltage;
//extern uint16 battery_voltage;
//void battery_voltage_get(void);
//
//#endif /* BATTERY_H_ */
