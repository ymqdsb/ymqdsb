/*
 * TFT.h
 *
 *  Created on: 2024��3��24��
 *      Author: ������
 */

#ifndef TFT_H_
#define TFT_H_
#include "zf_common_headfile.h"
#define KEY1     A8
#define KEY2     D8
#define KEY3     B12
#define KEY4     B0
extern int start_flag;
extern int star;
void imageshow(void);
void GET_RUN_KEY(void);
#endif /* TFT_H_ */
