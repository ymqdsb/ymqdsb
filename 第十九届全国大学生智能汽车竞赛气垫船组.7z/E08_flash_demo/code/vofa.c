/*
 * vofa.c
 *
 *  Created on: 2024��3��20��
 *      Author: ������
 */


#include "zf_common_headfile.h"
#include"vofa.h"




void Float_to_Byte(float f,unsigned char byte[])
{
    FloatLongType fl;
       fl.fdata=f;
       byte[0]=(uint8)fl.ldata;
       byte[1]=(uint8)(fl.ldata>>8);
       byte[2]=(uint8)(fl.ldata>>16);
       byte[3]=(uint8)(fl.ldata>>24);
}

void vofa_send_data (float f)
{uint8 byte[4]={0};
Float_to_Byte(f,byte);
    uart_write_byte(UART_7, byte[0]);
        uart_write_byte(UART_7, byte[1]);
        uart_write_byte(UART_7, byte[2]);
        uart_write_byte(UART_7, byte[3]);

}
void vofa_tail(void)
{
    uart_write_byte(UART_7, 0x00);
    uart_write_byte(UART_7, 0x00);
    uart_write_byte( UART_7,0x80);
    uart_write_byte( UART_7,0x7f);
}

